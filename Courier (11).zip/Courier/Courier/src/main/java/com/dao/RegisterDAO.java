package com.dao;

import com.model.CourierModel;
import com.model.LoginModel;
import com.model.SecretModel;

public interface RegisterDAO {
	public void insert(CourierModel cm);
public void insertSecretQn(SecretModel secret,CourierModel login);
	public boolean authenticate(LoginModel cm);
	
	public void insertRole(CourierModel cm);
}

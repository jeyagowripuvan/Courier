package com.dao;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.*;
import java.util.Properties;

import com.model.CourierModel;
import com.model.LoginModel;
import com.model.SecretModel;

public class RegisterDAOImpl implements RegisterDAO {
	String name;

	private static Properties prop = new Properties();

	public void insert(CourierModel cm) {
		Connection conn;
		conn = null;
		PreparedStatement ps;
		ps = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/courier", "root", "root");
			System.out.print("hi");
			String sql = "insert into register"
					+ "(firstname,lastname,gender,username,emailid,phoneno,password,secret_question,secret_answer) values (?,?,?,?,?,?,?,?,?)";
			name=cm.getUserName();
			System.out.println(name+"in insert");
			ps = conn.prepareStatement(sql);

			ps.setString(1, cm.getFirstName());
			ps.setString(2, cm.getLastName());
			ps.setString(3, cm.getGender());
			ps.setString(4, cm.getUserName());
			ps.setString(5, cm.getEmailId());
			ps.setString(6, cm.getPhno());
			ps.setString(7, cm.getPassword());
			ps.setString(8,cm.getSecretQuestion() );
			ps.setString(9, cm.getSecretAnswer());
			ps.executeUpdate();
			ps.close();
		} catch (SQLException | ClassNotFoundException e) {
			System.out.println(e);
		}
	}

	public boolean authenticate(LoginModel cm) {
		Connection conn;
		int flag = 0;
		conn = null;
		Statement st;
		st = null;
		String username = null, password = null;
		String userName = null, passWord = null;
		try {
			// FileInputStream fin=new FileInputStream("dbproperties.properties");
			// prop.load(fin);
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/courier", "root", "root");
			// System.out.print("hi");
			st = conn.createStatement();
			String sql = "select username,password from register";
			ResultSet rs = st.executeQuery(sql);
			while (rs.next()) {
				username = rs.getString(1);
				password = rs.getString(2);
				// System.out.println(username);
				/// System.out.println(password);
				userName = cm.getUserName();
				passWord = cm.getPassword();

				if (username.equals(userName) && password.equals(passWord)) {
					flag = 1;
				} else {
					flag = 0;
				}

			}
		} catch (SQLException | ClassNotFoundException e) {
			System.out.println(e);
		}
		if (flag == 1)
			return true;
		else
			return false;
	}

	public void insertRole(CourierModel cm) {
		
		Connection conn;
		conn = null;
		PreparedStatement ps;
		ps = null;
		Statement st=null;
		int id=0;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/courier", "root", "root");
			System.out.print("hi");
			st = conn.createStatement();
			String name=cm.getUserName();
			String sql = "select id from register where username like '"+name+"'";
			ResultSet rs = st.executeQuery(sql);
			while(rs.next())
			{
				id=rs.getInt(1);
			}
			String sqlQuery = "insert into userroles"
					+ "(id,role) values (?,?)";
			ps = conn.prepareStatement(sqlQuery);

			ps.setInt(1, id);
			ps.setString(2, cm.getRole());
			ps.executeUpdate();
			ps.close();
		} catch (SQLException | ClassNotFoundException e) {
			System.out.println(e);
		}
		
	}
	

	public void insertSecretQn(SecretModel secret,CourierModel login) {
		Connection conn;
		conn = null;
		PreparedStatement ps;
		ps = null;
		Statement st=null;
		Statement st1=null;
		int id=0;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/courier", "root", "root");
			System.out.print("hi");
			st = conn.createStatement();
			//CourierModel cm1=new CourierModel();
			//cm1.setUserName("ajay");
			//String name=login.getUserName();
			System.out.println(name);
			String sql = "select id from register where username = '"+name+"'";
			ResultSet rs = st.executeQuery(sql);
			while(rs.next())
			{
				id=rs.getInt(1);
			}

			System.out.println(id);
			String sq=secret.getSecretQuestion();
			String sa=secret.getSecretAnswer();
			System.out.println(sq+""+sa);
			String sql1="update register set secret_question=?,secret_answer=? where id=?";
			ps=conn.prepareStatement(sql1);
			
			ps.setString(1, sq);
			ps.setString(2, sa);
			ps.setInt(3, id);
			ps.executeUpdate();
			System.out.println("hello");
		} catch (SQLException | ClassNotFoundException e) {
			System.out.println(e);
		}
		
	}
}
package com.controller;

import java.util.HashMap;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.dao.RegisterDAOImpl;
import com.model.CourierModel;
import com.model.LoginModel;
import com.model.OfferModel;
import com.model.PackageModel;
import com.model.QuoteModel;
import com.model.SecretModel;
import com.model.WarehouseModel;
import com.service.LoginValid;
import com.service.ReceiptService;

@Controller
@ComponentScan("com")
public class Couriercontroller {

	RegisterDAOImpl reg = new RegisterDAOImpl();
	int count = 0;

	@Autowired
	LoginValid valid = new LoginValid();

	@Autowired
	ReceiptService receiptService = new ReceiptService();

	@ModelAttribute("login")
	public CourierModel courierModel() {
		return new CourierModel();
	}

	@ModelAttribute("loginvalid")
	public LoginModel loginModel() {
		return new LoginModel();
	}

	@ModelAttribute("secret")
	public SecretModel secretModel() {
		return new SecretModel();
	}

	@ModelAttribute("package")
	public PackageModel packageModel() {
		return new PackageModel();
	}

	@ModelAttribute("quote")
	public QuoteModel quoteModel() {
		return new QuoteModel();
	}
	
	@ModelAttribute("offerObj")
    public OfferModel offerModel() {
           return new OfferModel();
    }


	@ModelAttribute("Secretqnlist")
	public Map<String, String> buildState() {
		Map<String, String> pairs = new HashMap<>();
		pairs.put("what is your pet name?", "what is your pet name?");
		pairs.put("what is your elementary school name?", "what is your elementary school name?");
		pairs.put("what is your childhood dream job?", "what is your childhood dream job?");
		return pairs;
	}

	@ModelAttribute("Statuslist")
	public Map<String, String> buildState1() {
		Map<String, String> pair = new HashMap<>();
		pair.put("accept", "accept");
		pair.put("decline", "decline");
		return pair;
	}

	// displays the initial login page
	@RequestMapping(value = "/initial", method = RequestMethod.GET)
	public String initialpage() {
		return "login";
	}

	// authenticates the login details
	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public String loginPage(@Valid @ModelAttribute("loginvalid") LoginModel loginvalid, BindingResult result,
			ModelMap map) {
		if (count < 3) {
			if (result.hasErrors()) {
				return "login";
			} else {
				String role = loginvalid.getRole();
				int bool = reg.authenticate(loginvalid, role);
				if (bool == 2) {
					String msg = "Sorry!!!!!Your request have been rejected by the admin.Register again ,if wanted!!!!";
					map.addAttribute("msg", msg);
					return "login";
				} else if (bool == 3) {
					String msg = "Your request have been submitted and please wait for the admin to accept it!!!!";
					map.addAttribute("msg", msg);
					return "login";
				} else if (bool == 1) {
					if (role.equals("Admin")) {
						return "adminhome";
					} else if (role.equals("Staff")) {
						return "staffhome";
					} else if (role.equals("User")) {
						String details = reg.getDetails(loginvalid);
						String[] sp = details.split(" ");
						map.addAttribute("msg", sp[0]);
						map.addAttribute("msg1", sp[1]);
						map.addAttribute("msg2", sp[2]);
						map.addAttribute("msg3", sp[3]);
						map.addAttribute("msg4", sp[4]);
						map.addAttribute("msg5", sp[5]);
						return "userpage";
					} else {
						return "home";
					}
				} else {
					String msg = "Please check your username and password and the role";
					map.addAttribute("msg", msg);
					count++;
					return "login";
				}
			}
		} else {
			String msg = "Not a valid user";
			map.addAttribute("msg", msg);
			return "login";
		}
	}

	// displaying the register page
	@RequestMapping(value = "/register", method = RequestMethod.GET)
	public String requestPage() {
		return "register";
	}

	// validating the register page
	@RequestMapping(value = "/valid", method = RequestMethod.GET)
	public String registerPage(@Valid @ModelAttribute("login") CourierModel login, BindingResult result,ModelMap map) {
		if (result.hasErrors())
			return "register";
		else {
			int bool=reg.insert(login);
			if(bool>0)
			{
				String msg="You are registered successfully!!";
				map.addAttribute("msg",msg);
				reg.insertRole(login);
				reg.insertRequest(login);
				return "secret";
			}
			else
			{
				String msg="You are not registered!!";
				map.addAttribute("msg",msg);
				return "register";
			}
		}
	}

	// viewing the request
	@RequestMapping(value = "/registrationdetails", method = RequestMethod.GET)
	public String registrationDetailspage() {
		return "details";
	}

	// changing the status
	@RequestMapping(value = "/changeStatus", method = RequestMethod.GET)
	public String acceptpage(@ModelAttribute("loginValid") LoginModel loginValid, BindingResult result) {
		reg.acceptChange(loginValid);
		return "details";
	}

	// displaying the package registration page
	@RequestMapping(value = "/packagereg", method = RequestMethod.GET)
	public String packageRegistrationpage() {
		return "packageregistration";
	}

	// displaying the admin home page
	@RequestMapping(value = "/adminhomepage", method = RequestMethod.GET)
	public String adminHomepage() {
		return "adminhome";
	}

	// getting the secret qs and answer
	@RequestMapping(value = "/initial1", method = RequestMethod.GET)
	public String secretqnpage(@Valid @ModelAttribute("secret") SecretModel secret,
			@ModelAttribute("login") CourierModel login, BindingResult result, ModelMap map) {
		reg.insertSecretQn(secret, login);
		String msg = "Your request have been submitted and please wait for the admin to accept it!!!!";
		map.addAttribute("msg", msg);
		return "login";
	}

	// inserting the package details
	@RequestMapping(value = "/validpackreg", method = RequestMethod.GET)
	public String packageRegisterPage(@Valid @ModelAttribute("package") PackageModel pack, BindingResult result,
			ModelMap map) {
		if (result.hasErrors())
			return "packageregistration";
		else {
			int bool=reg.insertPackage(pack);
			if(bool>0)
			{
				String msg = "Package registered successfully";
				map.addAttribute("msg", msg);
				return "packageregistration";
			}
			else 
			{
				String msg = "Error in registering the package!!!";
				map.addAttribute("msg", msg);
				return "packageregistration";
			}
		}
	}

	// gets the secret qs and ans
	@RequestMapping(value = "/forgetuserid", method = RequestMethod.GET)
	public String forgetuseridPage(@ModelAttribute("secret") SecretModel secret, BindingResult result, ModelMap map) {
		int ch = reg.checkfruserid(secret);
		if (ch != 0) {
			String ch1 = String.valueOf(ch);
			map.addAttribute("userid", "user id is " + ch1);
			return "forgetuserid";
		} else {
			map.addAttribute("userid", "user id not available");
			return "forgetuserid";
		}
	}

	// displays the forget user id page
	@RequestMapping(value = "/dispforgetuserid", method = RequestMethod.GET)
	public String dispforgetuseridPage() {
		return "forgetuserid";
	}

	// displays forget password
	@RequestMapping(value = "/dispforgetpassword", method = RequestMethod.GET)
	public String dispforgetpasswordPage() {
		return "forgetpassword";
	}

	// displays change password page
	@RequestMapping(value = "/dispchange", method = RequestMethod.GET)
	public String dispchangepasswordPage(@ModelAttribute("secret") SecretModel secret, ModelMap map) {
		int ch = reg.checkfrpswd(secret);
		if (ch == 1) {
			return "changepassword";
		} else
			return "forgetpassword";
	}

	// gets the new password
	@RequestMapping(value = "/change", method = RequestMethod.GET)
	public String changepasswordPage(@ModelAttribute("secret") SecretModel login, ModelMap map) {
		int a = reg.changepassword(login);
		if (a == 1) {
			map.put("msg", "Your password has been changed successfully");
			return "changepassword";
		} else {
			map.put("msg", "Please check the password typed");
			return "changepassword";
		}
	}

	// package location updation
	@RequestMapping(value = "/packagelocation", method = RequestMethod.GET)
	public String packageLocationPage(@ModelAttribute("pack") PackageModel pack, BindingResult result, ModelMap map) {
		return "locationupdate";
	}

	//validates the package loaction and updates it
	@RequestMapping(value = "/validpackagelocation", method = RequestMethod.GET)
	public String packageUpdationPage(@ModelAttribute("pack") PackageModel pack, BindingResult result, ModelMap map) {
		valid.validate(pack, result);
		if (result.hasErrors()) {
			return "locationupdate";
		} else {
			reg.updateLocation(pack);
			String msg = "Package Location updated successfully";
			map.addAttribute("msg", msg);
			return "locationupdate";
		}
	}

	//displays the package delivery page
	@RequestMapping(value = "/packagedelivery", method = RequestMethod.GET)
	public String packageDeliveryPage() {
		return "packagedelivery";
	}
	
	//
	@RequestMapping(value = "/viewlocation", method = RequestMethod.GET)
	public String packageViewLocationPage(@ModelAttribute("pack") PackageModel pack, ModelMap map) {
		String str = reg.getLocation(pack);
		return "locationupdate";
	}

	//viewing the package registered
	@RequestMapping(value = "/packageview", method = RequestMethod.GET)
	public String packageViewPage(@ModelAttribute("pack") PackageModel pack, ModelMap map) {
		return "packageview";
	}
	
	//changing the delivery status(validation)
	@RequestMapping(value = "/changeDeliveryStatus", method = RequestMethod.GET)
	public String changeDeliveryStatusPage(@ModelAttribute("pack") PackageModel pack, ModelMap map) {
		reg.changeStatus(pack);
		return "packagedelivery";
	}

	@RequestMapping(value="/dispreceipt", method=RequestMethod.GET)
    public String dispreceiptPage(@ModelAttribute("quote")QuoteModel quote) {

return "consignmentreceipt";
    
    }

@RequestMapping(value="/receipt", method=RequestMethod.GET)
    public String receiptPage(@ModelAttribute("package")PackageModel pm,ModelMap map) {
double totcost=receiptService.calculateBill(pm);
map.addAttribute("Msg", "Total Cost of Parcel is"+String.valueOf(totcost));
return "consignmentreceipt";
    
    }


	//updating the profile
	@RequestMapping(value = "/updateprofile", method = RequestMethod.GET)
	public String dispupdateprofilePage() {
		return "updateprofile";
	}

	//package registration for staff
	@RequestMapping(value = "/packageregisterstaff", method = RequestMethod.GET)
	public String packageRegisterStaffPage(@ModelAttribute("secret") SecretModel secret, BindingResult result) {
		return "registerpackage";
	}
	
	//displaying the staff home page
	@RequestMapping(value = "/staffhomepage", method = RequestMethod.GET)
	public String staffHomepage(@ModelAttribute("login") CourierModel login) {
		return "staffhome";
	}

	//package location updation for staff
	@RequestMapping(value = "/packagelocationupdation", method = RequestMethod.GET)
	public String packageLocationUpdationPage(@ModelAttribute("pack") PackageModel pack) {
		return "updatelocation";
	}

	//package delivery for staff
	@RequestMapping(value = "/packagedeliverystaff", method = RequestMethod.GET)
	public String packageDeliveryStaffPage(@ModelAttribute("pack") PackageModel pack, BindingResult result,
			ModelMap map) {
		return "deliverypackage";
	}

	//updating the profile
	@RequestMapping(value = "/successprofile", method = RequestMethod.GET)
	public String successProfilepage(@ModelAttribute("login") CourierModel login, BindingResult result, ModelMap map) {
		String details = reg.getDetailsForUpdate(login);
		String[] sp = details.split(" ");
		map.addAttribute("msg", sp[0]);
		map.addAttribute("msg1", sp[1]);
		map.addAttribute("msg2", sp[2]);
		map.addAttribute("msg3", sp[3]);
		map.addAttribute("msg4", sp[4]);
		return "updateprofile";
	}

	//updation of profile
	@RequestMapping(value = "/successupdateprofile", method = RequestMethod.GET)
	public String updateUserPage(@ModelAttribute("login") CourierModel login, BindingResult result, ModelMap map) {
		reg.updateProfile(login);
		return "login";
	}

	//tracking of package by user
	@RequestMapping(value = "/trackpackage", method = RequestMethod.GET)
	public String trackPackagePage(@ModelAttribute("pack") PackageModel pack, BindingResult result, ModelMap map) {
		return "packagetrack";
	}

	//package delivery status by user
	@RequestMapping(value = "/getpackage", method = RequestMethod.GET)
	public String getPackagePage(@ModelAttribute("pack") PackageModel pack, BindingResult result, ModelMap map) {
		String details = reg.getPackageDetails(pack);
		String[] sp = details.split(" ");
		if (sp[0].equals("delivered")) {
			String status = "Your package is:Delivered!!!!!!!";
			map.addAttribute("status", status);
			return "packagetrack";
		} else {
			String status = "Your package is:Out for Delivery!!!!";
			status += "Your package has reached at " + sp[4] + " on " + sp[3];
			map.addAttribute("status", status);
			return "packagetrack";
		}
	}

	//updation of parcel types
	@RequestMapping(value = "/updateparcel", method = RequestMethod.GET)
	public String dispupdateparcelPage(@ModelAttribute("secret") SecretModel secret) {
		return "updateparceltype";
	}

	//updating the parcel types in database
	@RequestMapping(value = "/parceltype", method = RequestMethod.GET)
	public String dispparceltypePage(@ModelAttribute("quote") QuoteModel quote, ModelMap map) {
		int c = reg.insertparceltype(quote);
		if (c == 1) {
			map.addAttribute("msg", "Updated Successfully");
			return "updateparceltype";
		} else {
			map.addAttribute("msg", "Not Updated");
			return "updateparceltype";
		}
	}

	//updating the warehouse
	@RequestMapping(value = "/dispwarehouse", method = RequestMethod.GET)
	public String dispwarehousePage(@ModelAttribute("warehouse") WarehouseModel warehouse) {
		return "warehouse";
	}

	//updation of warehouse
	@RequestMapping(value = "/dispwarehouseupdate", method = RequestMethod.GET)
	public String dispwarehouseupdatePage(@ModelAttribute("warehouse") WarehouseModel warehouse) {
		return "warehouseupdate";
	}
	
	//updating the warehouse in database
	@RequestMapping(value = "/wareupdate", method = RequestMethod.GET)
	public String warehouseupdatepage(@ModelAttribute("warehouse") WarehouseModel warehouse, ModelMap map,
			BindingResult result) {
		boolean val = reg.updatewarehouse(warehouse);
		if (val == true) {
			map.put("msg", "Warehouse updated suceessfully");
			return "warehouseupdate";
		} else {
			map.put("msg", "Warehouse not updated");
			return "warehouseupdate";
		}
	}

	//inserting the warehouse 
	@RequestMapping(value = "/admin", method = RequestMethod.GET)
	public String dispadminPage(@Valid @ModelAttribute("warehouse") WarehouseModel warehouse, BindingResult result,
			ModelMap map) {
		if (result.hasErrors()) {
			return "warehouse";
		} else {
			int a = reg.insertwarehousedet(warehouse);
			if (a == 1) {
				map.addAttribute("msg", "Your details submitted successfully");
				return "warehouse";
			} else {
				map.addAttribute("msg", "Details not submitted");
				return "warehouse";
			}
		}
	}
	
	@RequestMapping(value = "/dispOfferUpdate",method=RequestMethod.GET)
    public String dispofferUpdatePage(@ModelAttribute("offerObj") OfferModel offerObj, ModelMap map,
            BindingResult result) {
		return "offerupdate";
    }
	
    //datbase calling
    @RequestMapping(value = "/updateaction",method=RequestMethod.GET)
    public String dispofferUpdateresult( @ModelAttribute("offerObj") OfferModel offerObj, ModelMap map,
                  BindingResult result) {
           boolean val=reg.offerDetails(offerObj);
           if (val == true) {
                  map.put("msg", "Offer updated suceessfully");
                  return "offerupdate";
           } else {
                  map.put("msg", "offer not updated");
                  return "offerupdate";
           }
    }
    
    @RequestMapping(value = "/staffdetails",method=RequestMethod.GET)
    public String dispofferUpdatePage(@ModelAttribute("loginvalid") LoginModel loginValid, ModelMap map,
            BindingResult result) {
		return "detailsstaff";
    }
    
    @RequestMapping(value = "/removestaff",method=RequestMethod.GET)
    public String removeStaffPage(@ModelAttribute("loginvalid") LoginModel loginValid, ModelMap map,
            BindingResult result) {
    	reg.deleteStaff(loginValid);
		return "detailsstaff";
    }
}

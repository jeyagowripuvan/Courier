package com.dao;

import com.model.CourierModel;
import com.model.LoginModel;
import com.model.OfferModel;
import com.model.PackageModel;
import com.model.QuoteModel;
import com.model.SecretModel;
import com.model.WarehouseModel;

public interface RegisterDAO {
	public int insert(CourierModel cm);

	public int authenticate(LoginModel cm,String role);
	
	public void insertRole(CourierModel cm);
	
	public void insertRequest(CourierModel cm);
	
	public void acceptChange(LoginModel cm);
	
	public void insertSecretQn(SecretModel secret,CourierModel login);
	
	public int insertPackage(PackageModel cm);
	
	public int changepassword(SecretModel cm);
	
	public int checkfruserid(SecretModel sm);
	
	public int checkfrpswd(SecretModel sm);
	
	public void updateLocation(PackageModel pm);
	
	public String getLocation(PackageModel pm);
	
	public void changeStatus(PackageModel pm);
	
	public double calculate(String type);
	
	public String getDetails(LoginModel cm);
	
	public String getDetailsForUpdate(CourierModel cm);
	
	public void updateProfile(CourierModel cm);
	
	public String getPackageDetails(PackageModel pm);
	
	public int insertparceltype(QuoteModel qm);
	
	 public boolean updatewarehouse(WarehouseModel wm);
	 
	 public int insertwarehousedet(WarehouseModel wm);
	
	 public boolean offerDetails(OfferModel om);
	 
	 public void deleteStaff(LoginModel om);
	 public double calculate(PackageModel pm);
}

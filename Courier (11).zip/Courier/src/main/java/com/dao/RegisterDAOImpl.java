package com.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import com.model.CourierModel;
import com.model.LoginModel;
import com.model.OfferModel;
import com.model.PackageModel;
import com.model.QuoteModel;
import com.model.SecretModel;
import com.model.WarehouseModel;

public class RegisterDAOImpl implements RegisterDAO {

	String name1;

	public int insert(CourierModel cm) {
		Connection conn;
		conn = null;
		PreparedStatement ps;
		ps = null;
		int condition = 0;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/courier", "root", "root");
			String sql = "insert into register"
					+ "(firstname,lastname,gender,username,email,phoneno,password,secret_question,secret_answer) values (?,?,?,?,?,?,?,?,?)";
			ps = conn.prepareStatement(sql);
			name1 = cm.getUserName();
			ps.setString(1, cm.getFirstName());
			ps.setString(2, cm.getLastName());
			ps.setString(3, cm.getGender());
			ps.setString(4, cm.getUserName());
			ps.setString(5, cm.getEmailId());
			ps.setString(6, cm.getPhno());
			ps.setString(7, cm.getPassword());
			ps.setString(8, cm.getSecretQuestion());
			ps.setString(9, cm.getSecretAnswer());
			condition = ps.executeUpdate();
			ps.close();
		} catch (SQLException | ClassNotFoundException e) {
			System.out.println(e);
		}
		return condition;
	}

	public int authenticate(LoginModel cm, String role) {
		Connection conn;
		int flag = 0;
		conn = null;
		Statement st;
		st = null;
		String username = null, password = null, status = null;
		String userName = null, passWord = null, Role = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/courier", "root", "root");
			st = conn.createStatement();
			String sql = "select username,password,status,u.role from register r inner join userroles u on r.id=u.id";
			ResultSet rs = st.executeQuery(sql);
			while (rs.next()) {
				username = rs.getString(1);
				password = rs.getString(2);
				status = rs.getString(3);
				Role = rs.getString(4);
				userName = cm.getUserName();
				passWord = cm.getPassword();
				if (username.equals(userName) && password.equals(passWord) && status.equals("accept")
						&& Role.equals(role)) {
					flag = 1;
					break;// if change
				} else if (username.equals(userName) && password.equals(passWord) && status.equals("decline")
						&& Role.equals(role)) {
					flag = 2;
					break;
				} else if (username.equals(userName) && password.equals(passWord) && status.equals("pending")
						&& Role.equals(role)) {
					flag = 3;
					break;
				}

			}
		} catch (SQLException | ClassNotFoundException e) {
			System.out.println(e);
		}
		return flag;
	}

	public void insertRole(CourierModel cm) {

		Connection conn;
		conn = null;
		PreparedStatement ps;
		ps = null;
		Statement st = null;
		int id = 0;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/courier", "root", "root");
			st = conn.createStatement();
			String name = cm.getUserName();
			String sql = "select id from register where username like '" + name + "'";
			ResultSet rs = st.executeQuery(sql);
			while (rs.next()) {
				id = rs.getInt(1);
			}
			String sqlQuery = "insert into userroles" + "(id,role) values (?,?)";
			ps = conn.prepareStatement(sqlQuery);

			ps.setInt(1, id);
			ps.setString(2, cm.getRole());
			ps.executeUpdate();
			ps.close();
		} catch (SQLException | ClassNotFoundException e) {
			System.out.println(e);
		}

	}

	public void insertRequest(CourierModel cm) {

		Connection conn;
		conn = null;
		PreparedStatement ps;
		ps = null;
		Statement st = null;
		int id = 0;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/courier", "root", "root");
			st = conn.createStatement();
			String name = cm.getUserName();
			String sql = "select id from register where username like '" + name + "'";
			ResultSet rs = st.executeQuery(sql);
			while (rs.next()) {
				id = rs.getInt(1);
			}
			String sqlQuery = "update register set status='pending' where id=" + id;
			ps = conn.prepareStatement(sqlQuery);
			ps.executeUpdate();
			ps.close();
		} catch (SQLException | ClassNotFoundException e) {
			System.out.println(e);
		}
	}

	public void acceptChange(LoginModel cm) {
		Connection conn;
		conn = null;
		PreparedStatement ps;
		ps = null;
		Statement st = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/courier", "root", "root");
			st = conn.createStatement();
			String id = cm.getId();
			int cid = Integer.parseInt(id);
			String status = cm.getStatus();
			String sqlQuery = "update register set status=? where id=" + id;
			ps = conn.prepareStatement(sqlQuery);
			ps.setString(1, status);
			ps.executeUpdate();
			ps.close();
		} catch (SQLException | ClassNotFoundException e) {
			System.out.println(e);
		}

	}

	public void insertSecretQn(SecretModel secret, CourierModel login) {
		Connection conn;
		conn = null;
		PreparedStatement ps;
		ps = null;
		Statement st = null;
		int id = 0;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/courier", "root", "root");
			st = conn.createStatement();
			System.out.println(name1);
			String sql = "select id from register where username = '" + name1 + "'";
			ResultSet rs = st.executeQuery(sql);
			while (rs.next()) {
				id = rs.getInt(1);
			}
			String sq = secret.getSecretQuestion();
			String sa = secret.getSecretAnswer();
			String sql1 = "update register set secret_question=?,secret_answer=? where id=?";
			ps = conn.prepareStatement(sql1);
			ps.setString(1, sq);
			ps.setString(2, sa);
			ps.setInt(3, id);
			ps.executeUpdate();
		} catch (SQLException | ClassNotFoundException e) {
			System.out.println(e);
		}

	}

	public int insertPackage(PackageModel cm) {

		Connection conn;
		conn = null;
		PreparedStatement ps;
		ps = null;
		int condition = 0;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/courier", "root", "root");
			String sql = "insert into package"
					+ "(pid,acceptdate,weight,cost,senderaddress,receiveraddress,customerid,employeeid) values (?,?,?,?,?,?,?,?)";
			ps = conn.prepareStatement(sql);
			ps.setString(1, cm.getConsignmentId());
			ps.setString(2, cm.getAcceptDate());
			ps.setDouble(3, cm.getWeight());
			ps.setDouble(4, cm.getCost());
			ps.setString(5, cm.getSenderAddress());
			ps.setString(6, cm.getReceiverAddress());
			ps.setString(7, cm.getCustomerId());
			ps.setString(8, cm.getEmployeeId());
			condition = ps.executeUpdate();
			String sql1 = "update package set status='accept' where pid=?";
			ps = conn.prepareStatement(sql1);
			ps.setString(1, cm.getConsignmentId());
			ps.executeUpdate();
			ps.close();
		} catch (SQLException | ClassNotFoundException e) {
			System.out.println(e);
		}
		return condition;

	}

	public int changepassword(SecretModel cm) {
		Connection conn;
		conn = null;
		PreparedStatement ps;
		ps = null;
		Statement st = null;
		int flag = 0;
		int id = 0;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/courier", "root", "root");
			st = conn.createStatement();
			String name1 = cm.getUserName();
			System.out.println(name1);
			String sql = "select id from register where username = '" + name1 + "'";
			ResultSet rs = st.executeQuery(sql);
			while (rs.next()) {
				id = rs.getInt(1);
			}
			String sql1 = "update register set password=? where id=?";
			String newps = cm.getNewpassword();
			String cnfrmpsw = cm.getConfirmpassword();
			ps = conn.prepareStatement(sql1);
			ps.setString(1, newps);
			ps.setInt(2, id);
			if (newps.equals(cnfrmpsw)) {
				ps.executeUpdate();
				flag = 1;
			}
		} catch (SQLException | ClassNotFoundException e) {
			System.out.println(e);
		}
		if (flag == 1)
			return 1;
		else
			return 0;
	}

	public int checkfruserid(SecretModel sm) {
		Connection conn;
		conn = null;
		Statement st = null;
		Statement st1 = null;
		int id = 0, flag = 0;
		String secqn1 = null, secans1 = null;
		String secqn = null, secans = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/courier", "root", "root");
			st = conn.createStatement();
			String name1 = sm.getUserName();
			String sql = "select id from register where username = '" + name1 + "'";
			ResultSet rs = st.executeQuery(sql);
			while (rs.next()) {
				id = rs.getInt(1);
			}
			secqn = sm.getSecretQuestion();
			secans = sm.getSecretAnswer();
			String sql1 = "select secret_question,secret_answer from register where id='" + id + "'";
			st1 = conn.createStatement();
			ResultSet rs1 = st.executeQuery(sql1);
			while (rs1.next()) {
				secqn1 = rs1.getString(1);
				secans1 = rs1.getString(2);
			}
			if (secqn.equals(secqn1) && secans.equals(secans1))
				flag = 1;
			else
				flag = 0;
		} catch (SQLException | ClassNotFoundException e) {
			System.out.println(e);
		}
		if (flag == 1)
			return id;
		else
			return 0;
	}

	public int checkfrpswd(SecretModel sm) {
		Connection conn;
		conn = null;
		Statement st = null;
		Statement st1 = null;
		int flag = 0;
		String secqn1 = null, secans1 = null;
		String secqn = null, secans = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/courier", "root", "root");
			st = conn.createStatement();
			int id = sm.getId();
			secqn = sm.getSecretQuestion();
			secans = sm.getSecretAnswer();
			String sql1 = "select secret_question,secret_answer from register where id='" + id + "'";
			st1 = conn.createStatement();
			ResultSet rs1 = st.executeQuery(sql1);
			while (rs1.next()) {
				secqn1 = rs1.getString(1);
				secans1 = rs1.getString(2);
			}
			if (secqn.equals(secqn1) && secans.equals(secans1))
				flag = 1;
			else
				flag = 0;
		} catch (SQLException | ClassNotFoundException e) {
			System.out.println(e);
		}
		if (flag == 1)
			return 1;
		else
			return 0;

	}

	public void updateLocation(PackageModel pm) {
		Connection conn;
		conn = null;
		PreparedStatement ps;
		ps = null;
		Statement st = null;
		int id = 0;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/courier", "root", "root");
			st = conn.createStatement();
			String senderAddress = pm.getSenderAddress();
			String packageId = pm.getConsignmentId();
			String date = pm.getAcceptDate();
			String sql1 = "update package set senderaddress=?,acceptdate=?,status='out for delivery' where pid=?";
			ps = conn.prepareStatement(sql1);
			ps.setString(1, senderAddress);
			ps.setString(2, date);
			ps.setString(3, packageId);
			ps.executeUpdate();
		} catch (SQLException | ClassNotFoundException e) {
			System.out.println(e);
		}

	}

	public String getLocation(PackageModel pm) {
		Connection conn;
		conn = null;
		PreparedStatement ps;
		ps = null;
		Statement st = null;
		int id = 0;
		String saddr, raddr, conca = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/courier", "root", "root");
			st = conn.createStatement();
			// String senderAddress=pm.getSenderAddress();
			String pid = pm.getConsignmentId();
			String sql = "select senderaddress,receiveraddress from package where pid='" + pid + "'";
			st = conn.createStatement();
			ResultSet rs = st.executeQuery(sql);
			saddr = rs.getString(1);
			raddr = rs.getString(2);
			conca = saddr + " " + raddr;

		} catch (SQLException | ClassNotFoundException e) {
			System.out.println(e);
		}

		return conca;

	}

	public void changeStatus(PackageModel pm) {
		Connection conn;
		conn = null;
		PreparedStatement ps;
		ps = null;
		Statement st = null;String raddr=null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/courier", "root", "root");
			st = conn.createStatement();
			String id = pm.getConsignmentId();
			int cid = Integer.parseInt(id);
			String sqlQuery = "update package set status='delivered' where pid=" + cid;
			ps = conn.prepareStatement(sqlQuery);
			ps.executeUpdate();
			st = conn.createStatement();
			String sqlQuery1 = "select receiveraddress from package where pid=" + cid;
			ResultSet rs = st.executeQuery(sqlQuery1);
			while(rs.next()) {
				System.out.println("sjdhgfgdfj");
			raddr = rs.getString(1);}
			System.out.println(raddr);
			String sqlQuery2 = "update package set senderaddress=? where pid=" + cid;
			ps = conn.prepareStatement(sqlQuery2);
			ps.setString(1, raddr);
			ps.executeUpdate();
			ps.close();
		} catch (SQLException | ClassNotFoundException e) {
			System.out.println(e);
		}
	}

	public double calculate(String type) {
		Connection conn;
		conn = null;
		PreparedStatement ps;
		ps = null;
		Statement st = null;
		double parcelCost = 0;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/courier", "root", "root");
			st = conn.createStatement();
			String sql = "select parcelcost from quote where parceltype like '" + type + "'";
			ResultSet rs = st.executeQuery(sql);
			while (rs.next()) {
				parcelCost = rs.getDouble(1);
			}
		} catch (SQLException | ClassNotFoundException e) {
			System.out.println(e);
		}
		return parcelCost;
	}

	public String getDetails(LoginModel cm) {
		Connection conn;
		conn = null;
		PreparedStatement ps;
		ps = null;
		Statement st = null;
		Statement st1 = null;
		int a = 0;
		int flag = 0;

		String fn = "", ln = "", gen = "", un = "", email = "", phn = "";
		String concat = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/courier", "root", "root");
			String userName = cm.getUserName();
			st = conn.createStatement();
			String sql1 = "select firstname,lastname,gender,username,email,phoneno from register where username like '"
					+ userName + "'";
			ResultSet rs = st.executeQuery(sql1);
			while (rs.next()) {
				fn = rs.getString(1);
				ln = rs.getString(2);
				gen = rs.getString(3);
				un = rs.getString(4);
				email = rs.getString(5);
				phn = rs.getString(6);
			}
			concat = fn + " " + ln + " " + gen + " " + un + " " + email + " " + phn;
		} catch (SQLException | ClassNotFoundException e) {
			System.out.println(e);
		}
		return concat;
	}

	public String getDetailsForUpdate(CourierModel cm) {
		Connection conn;
		conn = null;
		PreparedStatement ps;
		ps = null;
		Statement st = null;
		Statement st1 = null;
		int a = 0;
		int flag = 0;

		String fn = "", ln = "", gen = "", userName = "", email = "", phn = "";
		String concat = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/courier", "root", "root");
			String emailId = cm.getEmailId();
			st = conn.createStatement();
			String sql1 = "select firstname,lastname,username,email,phoneno from register where email like '" + emailId
					+ "'";
			ResultSet rs = st.executeQuery(sql1);
			while (rs.next()) {
				fn = rs.getString(1);
				ln = rs.getString(2);
				userName = rs.getString(3);
				email = rs.getString(4);
				phn = rs.getString(5);
			}
			concat = fn + " " + ln + " " + userName + " " + email + " " + phn;
		} catch (SQLException | ClassNotFoundException e) {
			System.out.println(e);
		}
		return concat;
	}

	public void updateProfile(CourierModel cm) {
		Connection conn;
		conn = null;
		PreparedStatement ps;
		ps = null;
		Statement st = null;
		int id = 0;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/courier", "root", "root");
			st = conn.createStatement();
			String emailId = cm.getEmailId();
			String sql1 = "update register set firstname=?,lastname=?,username=?,email=?,phoneno=? where email like '"
					+ emailId + "'";
			ps = conn.prepareStatement(sql1);
			ps.setString(1, cm.getFirstName());
			ps.setString(2, cm.getLastName());
			ps.setString(3, cm.getUserName());
			ps.setString(4, cm.getEmailId());
			ps.setString(5, cm.getPhno());
			ps.executeUpdate();
		} catch (SQLException | ClassNotFoundException e) {
			System.out.println(e);
		}

	}

	public String getPackageDetails(PackageModel pm) {
		Connection conn;
		conn = null;
		PreparedStatement ps;
		ps = null;
		Statement st = null;
		Statement st1 = null;
		int a = 0;
		int flag = 0;

		String fn = "", ln = "", gen = "", userName = "", email = "", phn = "";
		String concat = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/courier", "root", "root");
			String consignmentId = pm.getConsignmentId();
			st = conn.createStatement();
			String sql1 = "select status,acceptdate,senderaddress,receiveraddress from package where pid like '"
					+ consignmentId + "'";
			ResultSet rs = st.executeQuery(sql1);
			while (rs.next()) {
				email=rs.getString(1);
				fn = rs.getString(2);
				ln = rs.getString(3);
				userName = rs.getString(4);
			}
			concat = email+" "+fn + " " + ln + " " + userName;
		} catch (SQLException | ClassNotFoundException e) {
			System.out.println(e);
		}
		return concat;
	}

	public int insertparceltype(QuoteModel qm) {

		Connection conn;
		conn = null;
		PreparedStatement ps;
		ps = null;
		int a;
		a = 0;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/courier", "root", "root");
			String sql = "insert into quote" + "(weight,distance,costoftransport,parceltype) values (?,?,?,?)";
			ps = conn.prepareStatement(sql);
			ps.setDouble(1, qm.getParcelWeight());
			ps.setDouble(2, qm.getDistance());
			ps.setDouble(3, qm.getParcelCost());
			ps.setString(4, qm.getParcelType());
			a = ps.executeUpdate();
			ps.close();
		} catch (SQLException | ClassNotFoundException e) {
			System.out.println(e);
		}
		return a;
	}

	public int insertwarehousedet(WarehouseModel wm) {
		Connection conn;
		conn = null;
		PreparedStatement ps;
		ps = null;
		int fl = 0;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/courier", "root", "root");
			String sql = "insert into warehouse"
					+ "(branchid,branchname,branchlocation,contactnumber) values (?,?,?,?)";
			ps = conn.prepareStatement(sql);
			ps.setInt(1, wm.getBranchId());
			ps.setString(2, wm.getBranchName());
			ps.setString(3, wm.getBranchLocation());
			ps.setString(4, wm.getContactNumber());
			fl = ps.executeUpdate();
			ps.close();

		} catch (SQLException | ClassNotFoundException e) {
			System.out.println(e);
		}
		return fl;
	}

	public boolean updatewarehouse(WarehouseModel wm) {
		Connection conn;
		conn = null;
		PreparedStatement ps;
		ps = null;
		Statement st = null;
		Statement st1 = null;
		int flag = 0;
		int id = 0;
		int a = 0;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/courier", "root", "root");
			st = conn.createStatement();
			id = wm.getBranchId();
			String sql1 = "update warehouse set branchname=?,branchlocation=?,contactnumber=? where branchid=?";
			String br_name = wm.getBranchName();
			String br_loc = wm.getBranchLocation();
			String contact = wm.getContactNumber();
			ps = conn.prepareStatement(sql1);
			ps.setString(1, br_name);
			ps.setString(2, br_loc);
			ps.setString(3, contact);
			ps.setInt(4, id);
			int up = ps.executeUpdate();
			if (up > 0) {
				flag = 1;
			}
		} catch (SQLException | ClassNotFoundException e) {
			System.out.println(e);
		}
		if (flag == 1)
			return true;
		else
			return false;
	}

	public boolean offerDetails(OfferModel om) {
		Connection conn;
		conn = null;
		PreparedStatement ps;
		ps = null;
		int flag = 0;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/courier", "root", "root");
			String sql = "update offers set offerDiscount=? where offerPrice=?";
			ps = conn.prepareStatement(sql);
			ps.setString(1, om.getUpdateOfferDiscount());
			ps.setString(2, om.getUpdateOfferPrice());
			int up = ps.executeUpdate();
			if (up > 0) {
				flag = 1;
			}
		} catch (SQLException | ClassNotFoundException e) {
			System.out.println(e);
		}
		if (flag == 1)
			return true;
		else
			return false;

	}

	public void deleteStaff(LoginModel om) {
		Connection conn;
		conn = null;
		Statement ps;
		ps = null;
		int flag = 0;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/courier", "root", "root");
			String uid=om.getId();
		    ps=conn.createStatement();
			String sql = "delete from userroles where id="+uid;
			ps.executeUpdate(sql);
			ps=conn.createStatement();
			String sql1 = "delete from register where id="+uid;
			ps.executeUpdate(sql1);
		} catch (SQLException | ClassNotFoundException e) {
			System.out.println(e);
		}
	}

	public double calculate(PackageModel pm) {
        double w=pm.getWeight();
        Connection conn;
        conn = null;
        PreparedStatement ps;
        ps = null;
        Statement st,st1,st2;
        st=null;st1=null;st2=null;
        int a;a=0;
        double tot;tot=0;
        try {
               Class.forName("com.mysql.jdbc.Driver");
               conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/courier", "root", "root");
               System.out.println(w);
        String sql="select weight,costoftransport from quote";
        st=conn.createStatement();
        ResultSet rs=st.executeQuery(sql);
        double cos = 0;
        String we;
        while(rs.next())
        {
               we=rs.getString(1);
        cos=rs.getDouble(2);
        String[] sp=we.split(" ");
        double par=Double.parseDouble(sp[1]);
        //System.out.println(par);
        //System.out.println(w);
        if(w<par)
               break;
        }
        System.out.println(cos);
        String send=pm.getSenderAddress();
        String recv=pm.getReceiverAddress();
        String sql2="select senderaddress,recieveraddress from distance";
        st2=conn.createStatement();
        ResultSet rs2=st2.executeQuery(sql2);
String send1 = null,recv1 = null;
int fl=0;
        while(rs2.next())
        {
               send1=rs2.getString(1);
               recv1=rs2.getString(2);
               if(send.contains(send1)&&recv.contains(recv1))
               {fl=1;break;} 
        }
        
        if(fl==1) {
        String sql1="select cost from distance where senderaddress='"+send1+"' and recieveraddress='"+recv1+"'";
        System.out.println(send);
        System.out.println(recv);
        /*ps=conn.prepareStatement(sql1);
        ps.setString(1, send);
        ps.setString(2, recv);*/
        st1=conn.createStatement();
        ResultSet rs1=st1.executeQuery(sql1);
        double tcos = 0;
        while(rs1.next())
        {
        tcos=rs1.getDouble(1);    
        }
        System.out.println(tcos);
        tot=cos+tcos;
        }
        }
        catch (SQLException | ClassNotFoundException e) {
                     System.out.println(e);
               }
        return tot;
 }

}
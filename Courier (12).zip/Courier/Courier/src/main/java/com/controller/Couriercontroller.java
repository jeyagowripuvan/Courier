package com.controller;

import java.util.HashMap;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.dao.RegisterDAOImpl;
import com.model.CourierModel;
import com.model.LoginModel;
import com.model.SecretModel;

@Controller
@ComponentScan("com")
public class Couriercontroller {
	

	RegisterDAOImpl reg = new RegisterDAOImpl();

	@ModelAttribute("login")
	public CourierModel courierModel() {
		return new CourierModel();
	}
	@ModelAttribute("secret")
	public SecretModel secretModel() {
		return new SecretModel();
	}
	
	@ModelAttribute("Secretqnlist")
	 public Map<String,String> buildState() 
    {
		Map<String,String> pairs = new HashMap<>();
        pairs.put("what is your pet name?", "what is your pet name?");
        pairs.put("what is your elementary school name?", "what is your elementary school name?");
        pairs.put("what is your childhood dream job?", "what is your childhood dream job?");
        return pairs;
    }
	
	@ModelAttribute("loginvalid")
	public LoginModel loginModel() {
		return new LoginModel();
	}

	@RequestMapping(value = "/initial", method = RequestMethod.GET)
	public String initialpage(@ModelAttribute("login") CourierModel login) {

		return "login";

	}


	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public String loginPage(@Valid @ModelAttribute("loginvalid") LoginModel loginvalid, BindingResult result, ModelMap map) {
		System.out.println(result);
		if(result.hasErrors())
		{
			System.out.println("dsjhgfjd");
			return "login";
		}
		else {
		String role = loginvalid.getRole();
		System.out.println(role);
		boolean bool = reg.authenticate(loginvalid);
		System.out.println(bool);
		if (bool) {

			return "home";
		} else {
			String msg="Please check your username and password";
			map.addAttribute("msg", msg);
			return "login";
		}}
	}

	@RequestMapping(value = "/home")
	public String homePage(@ModelAttribute("login") CourierModel login, BindingResult result) {
		/*
		 * if(result.hasErrors()) {
		 * 
		 * return "login"; }
		 */
		// else {
		System.out.println("dfbfkhsgf");
		System.out.println(login.getUserName());
		return "login";
		// }

	}

	/*
	 * @RequestMapping(value="/register", method=RequestMethod.GET) public String
	 * registerPage(@Valid @ModelAttribute("login") CourierModel login,BindingResult
	 * result) { System.out.println(result); if(result.hasErrors()) { if(j>0) {
	 * 
	 * return "register"; } j++; return "register";
	 * 
	 * } else { System.out.println("jdhf"); return "register";}
	 * 
	 * }
	 */
	@RequestMapping(value = "/register", method = RequestMethod.GET)
	public String requestPage(@ModelAttribute("login") CourierModel login) {
		return "register";

	}

	

	@RequestMapping(value = "/valid", method = RequestMethod.GET)
	public String registerPage(@Valid @ModelAttribute("login") CourierModel login,BindingResult result) {
		System.out.println(result);
		if (result.hasErrors())
			return "register";
		else {
			System.out.println("jdhf");
			reg.insert(login);
			
			//reg.insertSecretQn(secret,login);
			return "secret";
		}

	}
	@RequestMapping(value = "/initial1", method = RequestMethod.GET)
	public String secretqnpage(@Valid @ModelAttribute("secret") SecretModel secret,@ModelAttribute("login") CourierModel login,BindingResult result) {
			System.out.println("jdhf");
			reg.insertSecretQn(secret,login);
			
			return "login";
		
	}

}

package com.service;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.model.CourierModel;
@Service
public class LoginValid implements Validator{

	
	public void validate(Object obj, Errors error) {
		
		CourierModel courier=(CourierModel)obj;
		ValidationUtils.rejectIfEmptyOrWhitespace(error,"userName","error.userName","User Name cannot be blank");
		//ValidationUtils.rejectIfEmptyOrWhitespace(error,"password","error.password","Password cannot be blank");
		String str=courier.getPassword();
		if(!(str.length()==8))
		{
			error.rejectValue("password","error.password","Password should be of length 8/Password should not be blank");
		}
		/*ValidationUtils.rejectIfEmptyOrWhitespace(error,"emailId","error.emailId","Email ID cannot be blank");
		ValidationUtils.rejectIfEmptyOrWhitespace(error,"confirmEmailId","error.confirmEmailId","Confirm Email ID cannot be blank");
		if(!(registorBean.getConfirmEmailId().equals(registorBean.getEmailId())))
		{
			error.rejectValue("emailId","error.emailId","Should be proper email ID format");
			error.rejectValue("confirmEmailId", "confirmEmailId", "Should be proper email ID format");
		}
		if(!(registorBean.isStatus()))
		{
			error.rejectValue("status","error.status","please agree to the terms and conditions");
		}*/
	
	}	 	  	    	    	     	      	 	

	public boolean supports(Class<?> arg0) {
		
		return false;
	}
	

}

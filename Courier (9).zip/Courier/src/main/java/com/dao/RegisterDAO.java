package com.dao;

import com.model.CourierModel;
import com.model.LoginModel;
import com.model.PackageModel;
import com.model.SecretModel;

public interface RegisterDAO {
	public void insert(CourierModel cm);

	public int authenticate(LoginModel cm,String role);
	
	public void insertRole(CourierModel cm);
	
	public void insertRequest(CourierModel cm);
	
	public void acceptChange(LoginModel cm);
	
	public void insertSecretQn(SecretModel secret,CourierModel login);
	
	public void insertPackage(PackageModel cm);
	
	public int changepassword(SecretModel cm);
	
	public int checkfruserid(SecretModel sm);
	
	public int checkfrpswd(SecretModel sm);
	
	public void updateLocation(PackageModel pm);
	
	public String getLocation(PackageModel pm);
	
	public void changeStatus(PackageModel pm);
	
	public double calculate(String type);
	
	public String getDetails(LoginModel cm);
	
}

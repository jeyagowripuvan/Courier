package com.model;

public class QuoteModel {

	private String parcelType;
	private int parcelCost;
	public String getParcelType() {
		return parcelType;
	}
	public void setParcelType(String parcelType) {
		this.parcelType = parcelType;
	}
	public int getParcelCost() {
		return parcelCost;
	}
	public void setParcelCost(int parcelCost) {
		this.parcelCost = parcelCost;
	}
}

package com.service;
import org.springframework.stereotype.Component;

import com.dao.RegisterDAOImpl;
import com.model.PackageModel;

@Component
public class ReceiptService {
                public double calculateBill(PackageModel pack)
                {
                	RegisterDAOImpl reg=new RegisterDAOImpl();
                	String parceltype="";
                	double weight=pack.getWeight();
                	if(weight>=10&&weight<=30)
                	{
                		parceltype="lightweight";
                	}
                	else if(weight>30&&weight<=70)
                	{
                		parceltype="moderateweight";
                	}
                	else if(weight>70&&weight<=150)
                	{
                		parceltype="heavyweight";
                	}
                	double parcelcost=reg.calculate(parceltype);
                	return parcelcost;
                }

}

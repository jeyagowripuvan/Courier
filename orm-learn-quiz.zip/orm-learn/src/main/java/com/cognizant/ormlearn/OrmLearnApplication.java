package com.cognizant.ormlearn;

import java.util.Date;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.cognizant.ormlearn.model.Attempt;
import com.cognizant.ormlearn.model.Department;
import com.cognizant.ormlearn.model.Employee;
import com.cognizant.ormlearn.model.Question;
import com.cognizant.ormlearn.model.Skill;
import com.cognizant.ormlearn.model.Stock;
import com.cognizant.ormlearn.service.AttemptService;
import com.cognizant.ormlearn.service.CountryService;
import com.cognizant.ormlearn.service.DepartmentService;
import com.cognizant.ormlearn.service.EmployeeService;
import com.cognizant.ormlearn.service.OptionService;
import com.cognizant.ormlearn.service.QuestionService;
import com.cognizant.ormlearn.service.SkillService;
import com.cognizant.ormlearn.service.StockService;
import com.cognizant.ormlearn.service.UserService;
@SpringBootApplication
public class OrmLearnApplication {
	private static AttemptService attemptService;
	private static QuestionService questionService;
	private static UserService userService;
	private static OptionService optionService;
	
	private static final Logger LOGGER = LoggerFactory.getLogger(OrmLearnApplication.class);
	
	public static void testAttempt()
	{
		LOGGER.info("Start");
		List<Question> questions = questionService.getQuestions();	
		for(Question que:questions) {
			LOGGER.info(que.getText());
			List<String> options = optionService.getOption(que.getQsInt());
			List<Integer> ans=optionService.getAns(que.getQsInt());
			for(int i=0;i<options.size();i++)
			{
				System.out.print(options.get(i)+"  ");
				System.out.print(ans.get(i)+" ");
				if(ans.get(i)!=0) {
					System.out.println("true");
				}
				else
					System.out.println("false");
			}
		}
		LOGGER.info("End");
	}
	
	public static void main(String[] args) {
		ApplicationContext context = SpringApplication.run(OrmLearnApplication.class, args);
		context.getBean(CountryService.class);
		userService=context.getBean(UserService.class);
		questionService=context.getBean(QuestionService.class);
		optionService=context.getBean(OptionService.class);
		testAttempt();
		
	}

}

package com.cognizant.ormlearn.repository;

import org.springframework.stereotype.Repository;

import com.cognizant.ormlearn.model.Attempt;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

@Repository
public interface AttemptRepository extends JpaRepository<Attempt,Integer>{
	
	@Query(value="SELECT a from attempt a where a.id=?1")
	public Attempt getAttempt(int userId, int attemptId);
}

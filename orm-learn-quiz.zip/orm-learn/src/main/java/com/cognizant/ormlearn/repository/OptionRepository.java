package com.cognizant.ormlearn.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cognizant.ormlearn.model.Option;

@Repository
public interface OptionRepository extends JpaRepository<Option,Integer>{

	@Query(value = "SELECT op_text from options where op_qt_id=?1",nativeQuery = true)
	List<String> getOption(int id);

	@Query(value = "SELECT op_score from options where op_qt_id=?1",nativeQuery = true)
	List<Integer> getAnswer(int id);
}

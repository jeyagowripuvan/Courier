package com.cognizant.ormlearn.repository;

import org.springframework.stereotype.Repository;

import com.cognizant.ormlearn.model.Question;

import org.springframework.data.jpa.repository.JpaRepository;
@Repository
public interface QuestionRepository extends JpaRepository<Question,Integer> {

}

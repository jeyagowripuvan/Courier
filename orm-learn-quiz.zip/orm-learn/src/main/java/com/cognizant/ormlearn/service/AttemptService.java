package com.cognizant.ormlearn.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.ormlearn.model.Attempt;
import com.cognizant.ormlearn.repository.AttemptRepository;
@Service
public class AttemptService {
	
	@Autowired
	private AttemptRepository attemptRepository;
	
	public Attempt getAttempt(int userId, int attemptId) {
		return attemptRepository.getAttempt(userId, attemptId);
	}
	@Transactional
	public void addAttempt(Attempt attempt) {

		attemptRepository.save(attempt);

	}
	@Transactional
	public Attempt get(int id) {
		return attemptRepository.findById(id).get();
	}
	
	@Transactional
	public void save(Attempt attempt) {
		attemptRepository.save(attempt);
	}

}

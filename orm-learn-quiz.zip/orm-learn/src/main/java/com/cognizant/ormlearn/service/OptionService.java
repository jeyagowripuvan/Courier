package com.cognizant.ormlearn.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.ormlearn.model.Option;
import com.cognizant.ormlearn.repository.OptionRepository;

@Service
public class OptionService {
	
	@Autowired
	private OptionRepository optionRepository;
	
	@Transactional
	public void addEmployee(Option o) {
		optionRepository.save(o);
	}
	
	@Transactional
	public Option get(int id) {
		return optionRepository.findById(id).get();
	}
	
	@Transactional
	public void save(Option options) {
		optionRepository.save(options);
	}
	public List<String> getOption(int id) {
		List<String> list=optionRepository.getOption(id);
		return list;
	}
	public List<Integer> getAns(int id) {
		List<Integer> list=optionRepository.getAnswer(id);
		return list;
	}

}

package com.cognizant.ormlearn.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.ormlearn.model.Question;
import com.cognizant.ormlearn.repository.QuestionRepository;

@Service
public class QuestionService {
	
	@Autowired
	private QuestionRepository questionRepository;
	
	@Transactional
	public void addQuestion(Question question) {
		questionRepository.save(question);
	}
	
	@Transactional
	public Question get(int id) {
		return questionRepository.findById(id).get();
	}
	
	@Transactional
	public void save(Question question) {
		questionRepository.save(question);
	}
	
	public List<Question> getQuestions() {
		return questionRepository.findAll();
	}

}

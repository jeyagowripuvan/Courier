package com.cognizant.ormlearn.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.ormlearn.model.User;
import com.cognizant.ormlearn.repository.UserRepository;

@Service
public class UserService {
	@Autowired
	private UserRepository userRepository;
	@Transactional
	public void addUser(User user) {
		userRepository.save(user);
	}
	
	@Transactional
	public User get(int id) {
		return userRepository.findById(id).get();
	}
	
	@Transactional
	public void save(User user) {
		userRepository.save(user);
	}

}

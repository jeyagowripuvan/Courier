package com.cognizant.ormlearn;

import java.util.Date;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.cognizant.ormlearn.model.Department;
import com.cognizant.ormlearn.model.Employee;
import com.cognizant.ormlearn.model.Skill;
import com.cognizant.ormlearn.model.Stock;
import com.cognizant.ormlearn.service.CountryService;
import com.cognizant.ormlearn.service.DepartmentService;
import com.cognizant.ormlearn.service.EmployeeService;
import com.cognizant.ormlearn.service.SkillService;
import com.cognizant.ormlearn.service.StockService;
@SpringBootApplication
public class OrmLearnApplication {
	private static EmployeeService employeeService;
	private static DepartmentService departmentService;
	private static SkillService skillService;
	private static StockService stockService;
	private static final Logger LOGGER = LoggerFactory.getLogger(OrmLearnApplication.class);
	
	private static void testGetEmployee() {

		LOGGER.info("Start");
		Employee employee = employeeService.get(1);
		LOGGER.debug("Employee:{}", employee);
		LOGGER.debug("Department:{}", employee.getDepartment());
		LOGGER.debug("Skills:{}", employee.getSkillList());
		LOGGER.info("End");
		}
	
	private static void testAddEmployee()
	{
		Employee employee=new Employee();
		employee.setId(5);
		employee.setName("jeya");
		employee.setSalary(40000);
		employee.setPermanent(true);
		employee.setDateOfBirth(new Date(1998-04-02));
		Department dept=departmentService.get(23);
		employee.setDepartment(dept);
		employeeService.save(employee);
		LOGGER.debug("Employee:{}", employee);
		LOGGER.debug("Department:{}", employee.getDepartment());
	}
	
	private static void testUpdateEmployee()
	{
		Employee emp=employeeService.get(3);
		Department dept=departmentService.get(25);
		emp.setDepartment(dept);
		employeeService.save(emp);
		LOGGER.debug("Employee:{}", emp);
		LOGGER.debug("Department:{}", emp.getDepartment());
	}
	
	private static void testGetDepartment()
	{
		Department dept=departmentService.get(23);
		LOGGER.debug("Employees in the department:{}", dept.getEmployeeList());
	}
	
	private static void testAddSkillToEmployee()
	{
		Employee emp=employeeService.get(1);
		Skill skill=skillService.get(30);
		Set<Skill> skillList=emp.getSkillList();
		skillList.add(skill);
		emp.setSkillList(skillList);
		employeeService.save(emp);
		LOGGER.debug("Employee:{}", emp);
		LOGGER.debug("Skills:{}", emp.getSkillList());
	}
	
	public static void testGetAllPermanentEmployees() {
		LOGGER.info("Start");
		List<Employee> employees = employeeService.getAllPermanentEmployees();
		LOGGER.debug("Permanent Employees:{}", employees);
		employees.forEach(e -> LOGGER.debug("Skills:{}", e.getSkillList()));
		LOGGER.info("End");
	}
	
	public static void testGetAverageSalary()
	{
		LOGGER.info("start");
		double averageSalary=employeeService.getAverageSalary(23);
		LOGGER.debug("Average Salary:{}",averageSalary);
		LOGGER.info("End");
	}
	
	public static void testGetAllEmployeesNative()
	{
		LOGGER.info("Start");
		List<Employee> employee=employeeService.getAllEmployeesNative();
		LOGGER.debug("Employees:{}",employee);
		LOGGER.info("End");
	}
	
	public static void testGetStockDetails()
	{
		LOGGER.info("Start");
		List<Stock> stock=stockService.getStockDetails();
		LOGGER.debug("Stock:{}",stock);
		LOGGER.info("End");
	}
	
	public static void main(String[] args) {
		ApplicationContext context = SpringApplication.run(OrmLearnApplication.class, args);
		context.getBean(CountryService.class);
		employeeService = context.getBean(EmployeeService.class);
		stockService=context.getBean(StockService.class);
		//departmentService = context.getBean(DepartmentService.class);
		//skillService = context.getBean(SkillService.class);
		//testGetEmployee();
		//testAddEmployee();
		//testUpdateEmployee();
		//testGetDepartment();
		//testAddSkillToEmployee();
		//testGetAllPermanentEmployees();
		//testGetAverageSalary();
		//testGetAllEmployeesNative();
		testGetStockDetails();
	}

}

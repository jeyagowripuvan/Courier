package com.cognizant.ormlearn.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="question")
public class Question {
	
	@Id
	@Column(name="qt_id")
	private int qsInt;
	@Column(name="qt_text")
	private String text;
	public int getQsInt() {
		return qsInt;
	}
	public void setQsInt(int qsInt) {
		this.qsInt = qsInt;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}

}

package com.cognizant.ormlearn.service;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cognizant.ormlearn.model.Country;
import com.cognizant.ormlearn.repository.CountryRepository;
import com.cognizant.ormlearn.service.exception.CountryNotFoundException;

@Service
public class CountryService {

	@Autowired
	private CountryRepository countryRepositry;
	
	@Transactional
	public List<Country> getAllCountries()
	{
		List<Country> list=countryRepositry.findAll();
		return list;
	}
	
	@Transactional
	public Country findCountryByCode(String countryCode) throws CountryNotFoundException{
		try {
			Optional<Country> result = countryRepositry.findById(countryCode);
			if (!result.isPresent())
			{
				throw new CountryNotFoundException("Country not found");
			}
			else
			{
				Country country = result.get();
				return country;
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return null;
	}
	
	
	@Transactional
	public void addCountry(Country country)
	{
		countryRepositry.save(country);
	}
	
	@Transactional
	public void updateCountry(String code,String name)
	{
		try {
			Country con=findCountryByCode(code);
			con.setName(name);
			countryRepositry.save(con);
		} catch (CountryNotFoundException e) {
			System.out.println(e);
		}
	}
	
	@Transactional
	public void deleteCountry(String code)
	{
		countryRepositry.deleteById(code);
	}
	
}
